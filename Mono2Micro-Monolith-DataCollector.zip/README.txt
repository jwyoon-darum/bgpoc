This Mono2Micro-Monolith-DataCollector.zip file contains Flicker, a Java based tool that is used to record test case executions in collecting monolith application data for Mono2Micro.

For details of the usage of Flicker refer to Section 3 of the "Mono2Micro User Guide", Version 2.0.
